#!/usr/bin/perl
use strict;
use warnings;

# all parameters for the default calculation
my $L = 3.2;      # single coil length
my $R = 12/2;     # coil radius
my $H = 14+$L/2;  # distance between coils
my $NL = 1;       # number of layers
my $N = 34;       # number of turns per layer
my $I0 = 1;

# Calculation range (will be changed below)
my $rm = 5;
my $dr = 0.2;
my $zm = 5;
my $dz = 0.2;


# the calculation itself
# -- run the calculation with magneettiSH + magnet programs
# -- read data and calculate best fits and differences
# Parameters:
#  base - basename for result files
#  func - function type 0 - const, 1-lin, 2-quadr, 4-four-power
sub calc{
  my $base = "rf";
  my $cmd;

  $cmd.= sprintf("coil %f %f %f %i %i %f 1\n", $L, $R, $H/2, $NL, $N, $I0);
  $cmd.= sprintf("wire %f %f\n", 0.07, 0);
  $cmd.= sprintf("field 0 %f %f %f %f %f\n", $dr, $rm, -$zm, $dz, $zm);

  my $txtfile = $base . '.txt';
  my $cmdfile = $base . '.cmd';
  my $resfile = $base . '.fld';
  my $fitfile = $base . '.fit';

  # run the actual calculation program
  open C, "> $txtfile" or die "can't open $txtfile: $!\n";
  printf C $cmd;
  close C;
  system("~/PROG/magneetti/magneettiSH $txtfile");
  system("~/PROG/magneetti/magnet &>/dev/null < $cmdfile");

  ## read the calculated field profile, calculate integrals
  ## integral definitions see in ../opt_doc/
  open R, $resfile or die "can't open $resfile: $!\n";

  foreach(<R>){
    $_=~s/#.*//;
    $_=~s/^\s+//;
    next if (/^\s*$/);
    my ($z,$r,$Bz,$Br) = split /\s+/;
  }
}

#############################################################################
# just calculate and print all the parameters

calc();


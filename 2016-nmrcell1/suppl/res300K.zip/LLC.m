function LLC()
  pkg load optim

% Uin -----Cx----------- Uout
%       |     |    |
%       L  k  L    C
%       |     |    |
%      gnd   gnd  gnd
% 
% 
% U_{in}  = I_{L1} (Z_{L1}+R_1) + I_{L2} sqrt{Z_{L1}Z_{L2}} k
% U_{out} = I_{L2} (Z_{L2}+R_2) + I_{L1} sqrt{Z_{L1}Z_{L2}} k
% U_{out} = I_{C} Z_{C}
% U_{in} - U_{out} = I_{Cx} Z_{Cx}
% I_{Cx} = I_{L2} + I_{C}
%
% ===========
% 3..5:
% I_{L2} = U_{in}/Z_{Cx} - U_{out}/Z_{Cx} - U_{out}/Z_{C}
% 
% ===========
% 1..2:
% I_{L1} = [U_{in} - k Uout sqrt{Z_{L1}Z_{L2}}/(Z_{L2}+R_2)]/
%          [Z_{L1} + R_1 - k^2 Z_{L1}Z_{L2}/(Z_{L2}+R_2]
% ===========
%
% U_{out}/U_{in} =
%   [(Z_{L2}+R_2)/Z_{Cx} + sqrt{Z_{L1}Z_{L2}} k/ZZ]/
%   [ 1 + (Z_{L2}+R_2)(1/Z_{Cx} + 1/Z_{C}) + k^2 Z_{L1}Z_{L2}/(Z_{L2}+R_2)/ZZ]
%   ZZ=Z_{L1} + R_1 - k^2 Z_{L1}Z_{L2}/(Z_{L2}+R_2)


%U_{out}/U_{in} =
% [ Z_{L2}/Z_{Cx} + sqrt{Z_{L2}/Z_{L1}} k/(1-k^2) ]/
% [ 1 + k^2/(1-k^2) + Z_{L2}/Z_{Cx} + Z_{L2}/Z_{C} ]


%%%%%%%%%%%%%%%%

% M = sqrt{ZL1ZL2} k
% N = (ZL2+R_2)(ZL1+R_1)/M^2 + 1;
% Uo/Ui = (1/M + N/ZCx)/((N-1)/(ZL2+R_2) + N/ZCx + N/Zc)

% Ui/ZCx - Uo/ZCx - Uo/Zc = IL2 


%%%%%%%%%%%%%%%%

find_figure('LCC'); clf; hold on;

C0 = 180e-12;
L1 = 50.6e-6;
L2 = 50.6e-6;
R1  = 10;
R2  = 10;
RC  = 10;
k  = 0.001;
Cx  = 1e-12;
f = 0.1e6:2e3:1.5e6;
w = 2*pi*f;

p=[L1*1e6 R1 R2 RC C0*1e12 Cx*1e12 k*1e3 0.5];
%p = [43.9091 20.2083 169.9324 2.4262 2.6572];

ff = [];
nn = [];
for n=1:8;
  ff = [ff f];
  nn = [nn n*ones(size(f))];
end

%UU = resp(p, [ff nn]);
%plot(ff, abs(UU), 'b-');

%plot(real(UU), imag(UU), 'b-');

[N,F,RE,IM]=textread('fres1.txt', '%f %f %f %f', 'commentstyle', 'shell');
RE = RE * (sqrt(2)*sqrt(10));
IM = IM * (sqrt(2)*sqrt(10));

FF=[];
NN=[];
YR=[];
YI=[];
for n=1:8;
  ii=find(N==n-1);
  FF = [FF F(ii)'];
  NN = [NN n*ones(size(ii))'];
  YR = [YR RE(ii)'];
  YI = [YI IM(ii)'];
end

%opt = optimoptions('lsqcurvefit',...
%  'FunctionTolerance', 1e-12,...
%  'MaxIterations', 4000,...
%  'Algorithm', 'levenberg-marquardt');

p=lsqcurvefit(@resp, p, [FF NN], [YR YI], [], [])
UU = resp(p, [ff nn]);
UU = UU(1:end/2) + i*UU(end/2+1:end);
%plot(ff, abs(UU), 'b-');
%plot(FF, hypot(RE,IM), 'r.');

plot(ff, imag(UU), 'r-');
plot(FF, IM, 'r.');
plot(ff, real(UU), 'b-');
plot(FF, RE, 'b.');

%plot(real(UU),imag(UU), 'b-');
%plot(RE,IM, 'r.-');


end


function UU = resp(p, x)
  f=x(1:end/2);
  n=x(end/2+1:end);

  CC = [406 607 813 1011 1218 1618 2031 2430]*1e-12;
  C = CC(n);

  L1 = p(1)*1e-6;
  L2 = p(1)*1e-6;
  R1 = p(2);
  R2 = p(3);
  RC = p(4);
  C0 = p(5)*1e-12;
  Cx = p(6)*1e-12;
  k  = p(7)*1e-3;
  phi = p(8);

  w = 2*pi*f;
  ZL1 = i*w*L1;
  ZL2 = i*w*L2;
  ZC = 1./(i*w.*(C+C0)) + RC;
  ZCx = 1./(i*w*Cx);

  ZZ = ZL1 + R1 - k^2.*ZL1.*ZL2./(ZL2+R2);

  % exact solution
    UU = ( (ZL2+R2)./ZCx + sqrt(ZL1.*ZL2)*k./ZZ )./...
      ( 1 + (ZL2+R2).*(1./ZCx+1./ZC) + k^2*ZL1.*ZL2./(ZL2+R2)./ZZ);

  % approx for k<<1, works good
  %UU = ( (ZL2+R2)./ZCx + sqrt(ZL1.*ZL2)*k./(ZL1 + R1))./...
  %   ( 1 + (ZL2+R2).*(1./ZCx+1./ZC));

  M0 = sqrt(ZL1.*ZL2)*k;
  M1 = (ZL2+R2) .* (ZL1+R1)./M0.^2 + 1;
  UU = (1./M0 + M1./ZCx)./((M1-1)./(ZL2+R2) + M1./ZCx + M1./ZC);


  UU = UU*exp(i*phi);
  UU = [real(UU) imag(UU)];
end

function plot_full_field()
  [z,r,Bz0,Br0,Bz1,Br1,Bz2,Br2,Bz3,Br3,Bz4,Br4] =...
    textread('sol.txt', "%f %f %f %f %f %f %f %f %f %f %f %f",...
      "commentstyle", "shell");

Nz = length(unique(z))
Nr = length(unique(r))

z = reshape(z,Nz,Nr);
r = reshape(r,Nz,Nr);
Bz0 = reshape(Bz0,Nz,Nr);
Br0 = reshape(Br0,Nz,Nr);
Bz1 = reshape(Bz1,Nz,Nr);
Br1 = reshape(Br1,Nz,Nr);
Bz2 = reshape(Bz2,Nz,Nr);
Br2 = reshape(Br2,Nz,Nr);
Bz3 = reshape(Bz3,Nz,Nr);
Br3 = reshape(Br3,Nz,Nr);
Bz4 = reshape(Bz4,Nz,Nr);
Br4 = reshape(Br4,Nz,Nr);

B1 = sqrt(Bz1.^2+Br1.^2);

figure(); clf; hold on;

  subplot(4,2,1); hold on;
  surface(z,r,B1, 'linestyle', 'none');
  xlim([-70 70]);

  subplot(4,2,3); hold on;
  surface(z,r,Bz2, 'linestyle', 'none');
  xlim([-70 70]);

  subplot(4,2,5); hold on;
  surface(z,r,Bz3, 'linestyle', 'none');
  xlim([-70 70]);

  subplot(4,2,7); hold on;
  surface(z,r,Bz4, 'linestyle', 'none');
  xlim([-70 70]);

  ii=find(r==0);
  subplot(4,2,2); hold on;
  plot(z(ii),Bz1(ii), 'b-');
  xlim([-70 70]);

  subplot(4,2,4); hold on;
  plot(z(ii),Bz2(ii), 'b-');
  plot([-70 70],[0 0], 'k-');
  xlim([-70 70]);

  subplot(4,2,6); hold on;
  plot(z(ii),Bz3(ii), 'b-');
  xlim([-70 70]);

  subplot(4,2,8); hold on;
  plot(z(ii),Bz4(ii), 'b-');
  xlim([-70 70]);

  print -color -deps field.eps
  print -color -dpng field.png

fprintf('max absolute field: %f\n',...
  max(max(abs(B1))));

rmax = max(r);
ii=find(r>28);
fprintf('max field on the shield: %f\n',...
  max(max(abs(B1(ii)))));

ii=find(r>21 & r<22);
fprintf('max field on the solenoid: %f\n',...
  max(max(abs(B1(ii)))));

end

